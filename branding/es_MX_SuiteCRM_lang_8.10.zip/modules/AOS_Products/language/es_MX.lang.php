<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'Id de usuario asignado',
    'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
    'LBL_ID' => 'ID',
    'LBL_DATE_ENTERED' => 'Fecha de Creación',
    'LBL_DATE_MODIFIED' => 'Fecha de Modificación',
    'LBL_MODIFIED' => 'Modificado Por',
    'LBL_MODIFIED_NAME' => 'Modified By Name',
    'LBL_CREATED' => 'Creado Por',
    'LBL_DESCRIPTION' => 'Descripción',
    'LBL_DELETED' => 'Eliminado',
    'LBL_NAME' => 'Nombre del Producto',
    'LBL_CREATED_USER' => 'Creado por el Usuario',
    'LBL_MODIFIED_USER' => 'Modificado por el Usuario',
    'LBL_LIST_FORM_TITLE' => 'Lista de Productos',
    'LBL_MODULE_NAME' => 'Products',
    'LBL_MODULE_TITLE' => 'Productos: Inicio',
    'LBL_HOMEPAGE_TITLE' => 'Mis Productos',
    'LNK_NEW_RECORD' => 'Crear producto',
    'LNK_LIST' => 'Ver Productos',
    'LBL_SEARCH_FORM_TITLE' => 'Buscar Productos',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
    'LBL_NEW_FORM_TITLE' => 'Nuevo Producto',
    'LBL_MAINCODE' => 'Código del Producto',
    'VALUE' => 'Product Name',
    'LBL_PART_NUMBER' => 'Part Number',
    'LBL_CATEGORY' => 'Categoría',
    'LBL_TYPE' => 'Tipo de Producto',
    'LBL_COST' => 'Costo',
    'LBL_PRICE' => 'Precio',
    'LBL_URL' => 'URL',
    'LBL_CONTACT' => 'Contact',
    'LBL_PRODUCT_IMAGE' => 'Imagen del Producto',
    'LBL_IMAGE_UPLOAD_FAIL' => 'ERROR: el archivo subido excede el tamaño máximo: max filesize: ',
    'LBL_AOS_PRODUCT_CATEGORYS_NAME' => 'Categoría de Producto',
    'LBL_AOS_PRODUCT_CATEGORY' => 'ID de la Categoría de Producto',
    'LBL_AOS_PRODUCT_CATEGORIES' => 'Product Categories',
    'LBL_COST_USDOLLAR' => 'Costo (Moneda Predeterminada)',
    'LBL_PRICE_USDOLLAR' => 'Precio (Moneda Predeterminada)',
    'LBL_FILE_URL' => 'URL de archivo',
    'LBL_CUSTOMERS_PURCHASED_PRODUCTS_SUBPANEL_TITLE' => 'Compras',
    'LBL_PRODUCTS_PURCHASES' => 'Purchases',
    'LBL_AOS_QUOTE_NAME' => 'Cotización',
    'LBL_ACCOUNT_NAME' => 'Account',
);
