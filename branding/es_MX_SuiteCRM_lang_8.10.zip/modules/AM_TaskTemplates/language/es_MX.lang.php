<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'Id de usuario asignado',
    'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
    'LBL_ID' => 'ID',
    'LBL_DATE_ENTERED' => 'Fecha de Creación',
    'LBL_DATE_MODIFIED' => 'Fecha de Modificación',
    'LBL_MODIFIED' => 'Modificado Por',
    'LBL_MODIFIED_ID' => 'Modificado por ID',
    'LBL_MODIFIED_NAME' => 'Modified By Name',
    'LBL_CREATED' => 'Creado Por',
    'LBL_CREATED_ID' => 'Creado por ID',
    'LBL_DESCRIPTION' => 'Descripción',
    'LBL_DELETED' => 'Eliminado',
    'LBL_NAME' => 'Task Name',
    'LBL_CREATED_USER' => 'Creado por el Usuario',
    'LBL_MODIFIED_USER' => 'Modificado por el Usuario',
    'LBL_LIST_NAME' => 'Nombre',
    'LBL_EDIT_BUTTON' => 'Editar',
    'LBL_REMOVE' => 'Quitar',
    'LBL_LIST_FORM_TITLE' => 'Lista de plantillas de tareas de proyecto',
    'LBL_MODULE_NAME' => 'Project Task Templates',
    'LBL_MODULE_TITLE' => 'Project Task Templates',
    'LBL_HOMEPAGE_TITLE' => 'Mis plantillas de tareas de proyecto',
    'LNK_NEW_RECORD' => 'Crear plantillas de tareas de proyecto',
    'LNK_LIST' => 'Ver plantillas de tareas de proyecto',
    'LNK_IMPORT_AM_TASKTEMPLATES' => 'Importar plantillas de tareas de proyecto',
    'LBL_SEARCH_FORM_TITLE' => 'Buscar plantillas de proyecto de tareas',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
    'LBL_AM_TASKTEMPLATES_SUBPANEL_TITLE' => 'Project Task Templates',
    'LBL_NEW_FORM_TITLE' => 'Nueva plantilla de tareas de proyecto',
    'LBL_STATUS' => 'Estado',
    'LBL_PRIORITY' => 'Priority',
    'LBL_PERCENT_COMPLETE' => 'Porcentaje completado',
    'LBL_PREDECESSORS' => 'Predecessors',
    'LBL_MILESTONE_FLAG' => 'Bandera de hito',
    'LBL_RELATIONSHIP_TYPE' => 'Tipo de relación',
    'LBL_TASK_NUMBER' => 'Número de tarea',
    'LBL_ORDER_NUMBER' => 'Orden ',
    'LBL_ESTIMATED_EFFORT' => 'Esfuerzo estimado (horas)',
    'LBL_UTILIZATION' => 'Utilización (%)',
    'LBL_DURATION' => 'Duración (días)',
    'LBL_AM_TASKTEMPLATES_AM_PROJECTTEMPLATES_FROM_AM_PROJECTTEMPLATES_TITLE' => 'Project Templates',

    'LBL_AM_TASKTEMPLATES_AM_PROJECTTEMPLATES_FROM_AM_TASKTEMPLATES_TITLE' => 'Plantillas de tarea: Plantillas de proyecto a partir del nombre de plantillas de tarea',
);
