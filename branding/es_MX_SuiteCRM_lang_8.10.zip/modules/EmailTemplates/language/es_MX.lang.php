<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ADD_DOCUMENT' => 'Agregar un Documento',
    'LBL_ADD_FILE' => 'Agregar un archivo',
    'LBL_ATTACHMENTS' => 'Attachments',
    'LBL_BODY' => 'Cuerpo:',
    'LBL_CLOSE' => 'Cerrado:',
    'LBL_DESCRIPTION' => 'Descripción:',
    'LBL_EDIT_ALT_TEXT' => 'Editar texto plano',
    'LBL_EMAIL_ATTACHMENT' => 'Email Attachment',
    'LBL_HIDE_ALT_TEXT' => 'Ocultar texto plano',
    'LBL_HTML_BODY' => 'Cuerpo HTML',
    'LBL_INSERT_VARIABLE' => 'Insertar variable:',
    'LBL_INSERT_URL_REF' => 'Insert URL Reference',
    'LBL_INSERT_TRACKER_URL' => 'Insert Tracker URL:',
    'LBL_INSERT' => 'Insert',
    'LBL_LIST_DATE_MODIFIED' => 'Última Modificación',
    'LBL_LIST_DESCRIPTION' => 'Descripción',
    'LBL_LIST_FORM_TITLE' => 'Lista de plantillas de e-Mail',
    'LBL_LIST_NAME' => 'Nombre',
    'LBL_MODULE_NAME' => 'Email Templates',
    'LBL_MODULE_TITLE' => 'Plantillas de e-Mail : Inicio',
    'LBL_NAME' => 'Nombre:',
    'LBL_NEW_FORM_TITLE' => 'Create Email Template',
    'LBL_PUBLISH' => 'Publicación:',
    'LBL_RELATED_TO' => 'Related To:',
    'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de plantillas de e-Mail',
    'LBL_SHOW_ALT_TEXT' => 'Mostrar texto plano',
    'LBL_SUBJECT' => 'Subject:',
    'LBL_SUITE_DOCUMENT' => 'Document',
    'LBL_UPLOAD_FILE' => 'Subir Archivo',
    'LBL_TEXT_BODY' => 'Cuerpo de texto',
    'LBL_USERS' => 'Usuarios',

    'LNK_EMAIL_TEMPLATE_LIST' => 'View Email Templates',
    'LNK_IMPORT_NOTES' => 'Import Notes',
    'LNK_NEW_EMAIL_TEMPLATE' => 'Create Email Template',
    'LNK_NEW_EMAIL' => 'Archive Email',
    'LNK_NEW_SEND_EMAIL' => 'Compose Email',
    'LNK_SENT_EMAIL_LIST' => 'e-Mails enviados',
    'LNK_VIEW_CALENDAR' => 'Today',
    // for Inbox
    'LBL_NEW' => 'New',
    'LNK_MY_DRAFTS' => 'Borradores',
    'LNK_MY_INBOX' => 'Mi bandeja de entrada',
    'LBL_TEXT_ONLY' => 'Sólo texto',
    'LBL_SEND_AS_TEXT' => 'Enviar sólo texto',
    'LBL_ACCOUNT' => 'Account',
    'LBL_FROM_NAME' => 'Nombre del remitente',
    'LBL_PLAIN_TEXT' => 'Texto plano',
    'LBL_CREATED_BY' => 'Creado Por',
    'LBL_PUBLISHED' => 'Publicado',
    'LNK_VIEW_MY_INBOX' => 'Ver mi bandeja de entrada',
    'LBL_ASSIGNED_TO_ID' => 'Assigned To',
    'LBL_EDIT_LAYOUT' => 'Edit Layout' /*for 508 compliance fix*/,
    'LBL_SELECT' => 'Select' /*for 508 compliance fix*/,
    'LBL_ID_FF_CLEAR' => 'Clear' /*for 508 compliance fix*/,
    'LBL_TYPE' => 'Type',
    'LBL_WIDTH' => 'Ancho predeterminado',
    'LNK_IMPORT_CAMPAIGNS' => 'Importar Campaña',
);
