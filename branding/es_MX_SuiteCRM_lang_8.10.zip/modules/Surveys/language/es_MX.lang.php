<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID'                                     => 'Id de usuario asignado',
    'LBL_ADD_OPTION'                                         => 'Añadir nueva opción',
    'LBL_ASSIGNED_TO_NAME'                                   => 'Asignado a',
    'LBL_SECURITYGROUPS'                                     => 'Grupos de Seguridad',
    'LBL_SECURITYGROUPS_SUBPANEL_TITLE'                      => 'Grupos de Seguridad',
    'LBL_ID'                                                 => 'ID',
    'LBL_DATE_ENTERED'                                       => 'Fecha de Creación',
    'LBL_DATE_MODIFIED'                                      => 'Fecha de Modificación',
    'LBL_MODIFIED'                                           => 'Modificado Por',
    'LBL_MODIFIED_ID'                                        => 'Modificado por Id',
    'LBL_MODIFIED_NAME'                                      => 'Modified By Name',
    'LBL_CREATED'                                            => 'Creado Por',
    'LBL_CREATED_ID'                                         => 'Creado Por Id',
    'LBL_DESCRIPTION'                                        => 'Descripción',
    'LBL_DELETED'                                            => 'Eliminado',
    'LBL_NAME'                                               => 'Nombre',
    'LBL_CREATED_USER'                                       => 'Creado por el Usuario',
    'LBL_MODIFIED_USER'                                      => 'Modificado por el Usuario',
    'LBL_LIST_NAME'                                          => 'Nombre',
    'LBL_EDIT_BUTTON'                                        => 'Editar',
    'LBL_REMOVE'                                             => 'Quitar',
    'LBL_LIST_FORM_TITLE'                                    => 'Lista de encuestas',
    'LBL_MODULE_NAME'                                        => 'Encuestas',
    'LBL_MODULE_TITLE'                                       => 'Encuestas',
    'LBL_HOMEPAGE_TITLE'                                     => 'Mis encuestas',
    'LNK_NEW_RECORD'                                         => 'Crear encuestas',
    'LNK_LIST'                                               => 'Ver encuestas',
    'LNK_IMPORT_SURVEYS'                                     => 'Importar encuestas',
    'LBL_SEARCH_FORM_TITLE'                                  => 'Buscar encuestas',
    'LBL_HISTORY_SUBPANEL_TITLE'                             => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'                          => 'Activities',
    'LBL_SURVEYS_SUBPANEL_TITLE'                             => 'Encuestas',
    'LBL_NEW_FORM_TITLE'                                     => 'Nuevas encuestas',
    'LBL_STATUS'                                             => 'Estado',
    'LBL_SURVEY_QUESTIONS_DISPLAY'                           => 'Preguntas',
    'LBL_SURVEY_URL_DISPLAY'                                 => 'URL',
    'LBL_HAPPINESS_QUESTION'                                 => 'Pregunta de felicidad',
    'LBL_CANT_EDIT_RESPONDED'                                => 'No se pueden editar preguntas que ya tienen respuestas',
    'LBL_VIEW_SURVEY_REPORTS'                                => 'Ver reportes de encuesta',
    'LBL_CHECKED'                                            => 'Comprobado',
    'LBL_UNCHECKED'                                          => 'Sin comprobar',
    'LBL_RESPONSE_ANSWER'                                    => 'Respuesta',
    'LBL_RESPONSE_CONTACT'                                   => 'Contact',
    'LBL_RESPONSE_TIME'                                      => 'Date',
    'LBL_UNKNOWN_CONTACT'                                    => 'Unknown',
    'LBL_RESPONSE_COUNT'                                     => 'Count',
    'LBL_SUBMIT_TEXT'                                        => 'Enviar texto',
    'LBL_SATISFIED_TEXT'                                     => 'Texto para Satisfecho',
    'LBL_NEITHER_TEXT'                                       => 'Texto para ni satisfecho ni insatifecho',
    'LBL_DISSATISFIED_TEXT'                                  => 'Texto para insatisfecho',
    'LBL_SURVEYS_SURVEYQUESTIONS_FROM_SURVEYQUESTIONS_TITLE' => 'Preguntas de la encuesta',
    'LBL_SURVEYS_SURVEYRESPONSES_FROM_SURVEYRESPONSES_TITLE' => 'Respuestas de Encuestas',
    'LBL_SHOW_RESPONSES' => 'Mostrar las respuestas',
    'LBL_HIDE_RESPONSES' => 'Ocultar respuestas',
    'LNK_LIST_SURVEY_RESPONSES' => 'Ver respuestas de la encuesta',
    'LBL_SURVEY_QUESTION' => 'Pregunta',
    'LBL_SURVEY_TEXT' => 'Text',
    'LBL_SURVEY_TYPE' => 'Type',
    'LBL_SURVEY_ACTIONS' => 'Actions',
    'LBL_SURVEY_NEW_QUESTION' => 'Nueva pregunta',
    'LBL_SURVEY_RESPONSES' => 'Nueva pregunta',
    'LBL_SURVEYS_SENT' => 'Encuestas enviadas:',
    'LBL_SURVEY_DISTINCT' => 'Encuestas Distintas Enviadas:',
    'LBL_DRAFT' => 'Draft',
    'LBL_SUBMIT' => 'Submit',
    'LBL_STARS' => 'Estrellas',
    'LBL_SURVEY_CLOSE_RESPONSE' => 'Gracias por tu interés, pero esta encuesta está ya está cerrada.',
    'LBL_SURVEY_THANKS' => 'Thanks for completing this survey.',
);
